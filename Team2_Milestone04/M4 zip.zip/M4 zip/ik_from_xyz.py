#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Float64
import numpy as np
import math

class InverseKinematicsNode(object):
    def __init__(self):
        rospy.init_node("ik_from_xyz")

        # -------- Robot link lengths [m] (same as your MATLAB script) --------
        self.l1 = rospy.get_param("~l1", 0.04355)
        self.l2 = rospy.get_param("~l2", 0.140)
        self.l3 = rospy.get_param("~l3", 0.1324)
        self.l4 = rospy.get_param("~l4", 0.01213)

        # -------- IK parameters (same as accurate_IK.m) --------
        self.alpha    = rospy.get_param("~alpha", 0.8)
        self.lambd    = rospy.get_param("~lambda", 1e-3)
        self.max_step = rospy.get_param("~max_step_deg", 4.0) * math.pi / 180.0
        self.tol      = rospy.get_param("~tol", 1e-5)
        self.max_iter = rospy.get_param("~max_iter", 400)

        # Initial guess q0 (deg -> rad)
        q0_deg = rospy.get_param("~q0_deg", [30.0, 60.0, 60.0, 90.0])
        self.q_prev = np.array(
            [math.radians(q0_deg[0]),
             math.radians(q0_deg[1]),
             math.radians(q0_deg[2]),
             math.radians(q0_deg[3])],
            dtype=float
        )

        # -------- Joint command publishers (radians to Gazebo) --------
        # IMPORTANT:
        #   We have 4 IK joints: q1, q2, q3, q4
        #   but we send q4 -> Joint_5 in URDF (Joint_4 is "invisible"/ignored)
        joint_names  = rospy.get_param(
            "~joint_names",
            ["Joint_1", "Joint_2", "Joint_3", "Joint_5"]   # <-- Joint_5 instead of Joint_4
        )
        joint_topics = rospy.get_param(
            "~joint_topics",
            ["/Joint_1/command",
             "/Joint_2/command",
             "/Joint_3/command",
             "/Joint_5/command"]                           # <-- publish q4 here
        )

        if len(joint_names) != 4 or len(joint_topics) != 4:
            rospy.logfatal("Need exactly 4 joint names and 4 joint topics.")
            raise SystemExit

        self.joint_pubs = []
        for name, topic in zip(joint_names, joint_topics):
            pub = rospy.Publisher(topic, Float64, queue_size=10)
            self.joint_pubs.append(pub)
            rospy.loginfo("IK will publish %s on %s (radians)", name, topic)

        # -------- Subscribe to desired EE pose --------
        desired_topic = rospy.get_param("~desired_topic", "desired_ee_pose")
        self.sub = rospy.Subscriber(desired_topic,
                                    PoseStamped,
                                    self.pose_callback,
                                    queue_size=1)
        rospy.loginfo("IK node ready. Subscribing to %s", desired_topic)

    # ---------- DH and FK, same as MATLAB ----------

    def dh(self, th, d, a, al):
        cth = math.cos(th);  sth = math.sin(th)
        ca  = math.cos(al);  sa  = math.sin(al)
        return np.array([[ cth, -sth*ca,  sth*sa, a*cth],
                         [ sth,  cth*ca, -cth*sa, a*sth],
                         [  0 ,     sa ,     ca ,   d   ],
                         [  0 ,      0 ,      0 ,   1   ]], dtype=float)

    def fk_position(self, q):
        T1 = self.dh(q[0], self.l1, 0.0, math.pi/2.0)
        T2 = self.dh(q[1]+math.pi/2.0, 0.0,      self.l2, math.pi)
        T3 = self.dh(q[2], 0.0,      self.l3, math.pi)
        T4 = self.dh(q[3], 0.0,      self.l4, 0.0)
        T  = T1.dot(T2).dot(T3).dot(T4)
        p  = T[0:3, 3]
        return p

    # ---------- accurate_IK translated from MATLAB ----------

    def accurate_ik(self, pos_des, q_init):
        q = q_init.copy()

        # Make base look toward the target
        q[0] = math.atan2(pos_des[1], pos_des[0])

        dqsmall = 1e-6
        I4 = np.eye(4)

        for _ in range(self.max_iter):
            p = self.fk_position(q)
            e = pos_des - p

            if np.linalg.norm(e) < self.tol:
                return q

            # Numerical Jacobian 3x4
            Jv = np.zeros((3, 4))
            for i in range(4):
                q_pert = q.copy()
                q_pert[i] += dqsmall
                p_pert = self.fk_position(q_pert)
                Jv[:, i] = (p_pert - p) / dqsmall

            JT = Jv.T
            A = JT.dot(Jv) + self.lambd * I4
            b = JT.dot(e)

            dq = np.linalg.solve(A, b)
            dq *= self.alpha

            dq = np.clip(dq, -self.max_step, self.max_step)
            q = q + dq

        rospy.logwarn("IK did not fully converge (||e|| = %.6f)", np.linalg.norm(e))
        return q

    def pose_callback(self, msg):
        pos_des = np.array([msg.pose.position.x,
                            msg.pose.position.y,
                            msg.pose.position.z],
                           dtype=float)

        q_sol = self.accurate_ik(pos_des, self.q_prev)
        self.q_prev = q_sol

        # Publish joint angles in RADIANS
        # q[0] -> Joint_1
        # q[1] -> Joint_2
        # q[2] -> Joint_3
        # q[3] -> Joint_5
        for i, pub in enumerate(self.joint_pubs):
            pub.publish(Float64(q_sol[i]))

    def spin(self):
        rospy.spin()


if __name__ == "__main__":
    node = InverseKinematicsNode()
    node.spin()

