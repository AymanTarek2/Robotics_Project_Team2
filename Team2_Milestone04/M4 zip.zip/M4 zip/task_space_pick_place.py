#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import PoseStamped
import numpy as np

class PickPlaceTrajectoryNode(object):
    def __init__(self):
        rospy.init_node("task_space_pick_place")

        # Same trajectory/timing parameters as MATLAB
        self.Ts = rospy.get_param("~Ts", 0.1)   # sampling time [s]
        self.Tf = rospy.get_param("~Tf", 3.0)   # time per segment [s]

        self.z_high = rospy.get_param("~z_high", 0.20)
        self.z_low  = rospy.get_param("~z_low", 0.10)

        x_left  = rospy.get_param("~x_left", 0.12)
        y_left  = rospy.get_param("~y_left", 0.10)
        x_right = rospy.get_param("~x_right", 0.12)
        y_right = rospy.get_param("~y_right", -0.10)

        # Waypoints in task space (same as MATLAB script)
        self.startXYZ    = np.array([0.07,     0.0,      self.z_high])
        self.left_above  = np.array([x_left,   y_left,   self.z_high])
        self.left_down   = np.array([x_left,   y_left,   self.z_low])
        self.left_up     = self.left_above.copy()
        self.right_above = np.array([x_right,  y_right,  self.z_high])
        self.right_down  = np.array([x_right,  y_right,  self.z_low])
        self.right_up    = self.right_above.copy()

        topic = rospy.get_param("~desired_topic", "desired_ee_pose")
        self.pub = rospy.Publisher(topic, PoseStamped, queue_size=10)

        rospy.sleep(1.0)
        rospy.loginfo("Task-space pick&place node ready, publishing on %s", topic)

    def run_segment(self, P0, Pf, label):
        rospy.loginfo("Segment: %s", label)

        Tf = self.Tf
        Ts = self.Ts

        N = int(Tf / Ts)
        if N < 2:
            N = 2

        t = np.linspace(0.0, Tf, N)

        # Cubic coefficients (exactly like MATLAB)
        a0 = P0
        a1 = np.zeros(3)
        a2 = 3.0 * (Pf - P0) / (Tf**2)
        a3 = -2.0 * (Pf - P0) / (Tf**3)

        rate = rospy.Rate(1.0 / Ts)
        for k in range(N):
            if rospy.is_shutdown():
                return
            tk = t[k]
            Pd = a0 + a1 * tk + a2 * (tk**2) + a3 * (tk**3)

            msg = PoseStamped()
            msg.header.stamp = rospy.Time.now()
            msg.header.frame_id = "world"
            msg.pose.position.x = float(Pd[0])
            msg.pose.position.y = float(Pd[1])
            msg.pose.position.z = float(Pd[2])

            # You can keep orientation constant for now
            msg.pose.orientation.x = 0.0
            msg.pose.orientation.y = 0.0
            msg.pose.orientation.z = 0.0
            msg.pose.orientation.w = 1.0

            self.pub.publish(msg)
            rate.sleep()

    def run(self):
        # Segment 1: start -> above left object
        self.run_segment(self.startXYZ, self.left_above,
                         "start -> above LEFT")

        rospy.loginfo(">>> Here you would CLOSE the gripper (Gazebo plugin / controller).")

        # Segment 2: go down to pick
        self.run_segment(self.left_above, self.left_down,
                         "DOWN to pick (LEFT)")

        # Segment 3: go up with object
        self.run_segment(self.left_down, self.left_up,
                         "UP with object (LEFT)")

        # Segment 4: move in air to above right
        self.run_segment(self.left_up, self.right_above,
                         "LEFT -> above RIGHT")

        # Segment 5: go down to place
        self.run_segment(self.right_above, self.right_down,
                         "DOWN to place (RIGHT)")

        rospy.loginfo(">>> Here you would OPEN the gripper.")

        # Segment 6: go back up after placing
        self.run_segment(self.right_down, self.right_up,
                         "UP after placing (RIGHT)")

        rospy.loginfo("Pick-and-place LEFT → RIGHT done.")


if __name__ == "__main__":
    node = PickPlaceTrajectoryNode()
    node.run()

